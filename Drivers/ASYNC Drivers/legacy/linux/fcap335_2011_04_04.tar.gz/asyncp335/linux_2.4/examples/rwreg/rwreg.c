/*
 * rwreg.c
 * User mode program to read or write the UART config registers.
 *
 * Note: If you don't know what these are, you shouldn't be using this
 *
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	struct rwreg rw;

	rw.rwselect=atoi(argv[2]);

	if( (argc!=5) && (argc!=4) )
	{
		printf("usage: %s device rw address [data] \n", argv[0]);
		printf("rw: 0 = read 1 = write\n");
		exit(1);
	}
	if (rw.rwselect)
	{
		if(argc!=5)
		{
			printf("write usage: %s device rw address data \n", argv[0]);
			printf("rw: 0 = read 1 = write\n");
			exit(1);
		}
		sscanf(argv[4],"%lx",&(rw.data));
		sscanf(argv[3],"%lx",&(rw.address));
	}
	else
	{
		if(argc!=4)
		{
			printf("read usage: %s device rw address \n", argv[0]);
			printf("rw: 0 = read 1 = write\n");
			exit(1);
		}
		rw.data=0;
		sscanf(argv[3],"%lx",&(rw.address));
	}
	
	printf("rwreg: Opening %s device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}
	if(ioctl(fc,FC_RW_REGISTER,&rw)==-1) 
	{
		perror(NULL);
	}
	else
	{
		if(rw.rwselect)
			printf("rwreg: Wrote 0x%2.2x to %s at offset 0x%2.2x\n", rw.data,argv[1],rw.address);
		else
			printf("rwreg: Read 0x%2.2x from %s at offset 0x%2.2x\n",rw.data,argv[1],rw.address);
	}

	close(fc);
	return 0;
}

/* $Id$ */
