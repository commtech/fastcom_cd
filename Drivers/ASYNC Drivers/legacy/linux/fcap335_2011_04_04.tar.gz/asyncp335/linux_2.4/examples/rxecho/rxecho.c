/* 
 * rxecho.c
 * User mode program to enable hardware receive exho cancel.
 * This feature can be helpful to users of 2-wire 485 who do not want receive
 * what they transmit.  It disables the hardware receiver during transmits. 
 * This is accomplished in hardware; it will not hurt performance.
 * 
 * Note1: This setting applies to all ports on the board.
 * Note2: To use this feature, you must have Auto485 and 485TxEnable enabled.
 *
 * Default: Off
 */
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	int onoff;

	if(argc!=3)
	{
		printf("usage: %s device onoff\n", argv[0]);
		printf("onoff: 0=off 1=oni\n");
		exit(1);
	}

	onoff = atoi(argv[2]);

	printf("rxecho: Opening \"%s\" device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}

	if(ioctl(fc,FC_RX_ECHO_CANCEL,&onoff)==-1) 
	{
		perror(NULL);
	}
	else
	{
		switch(onoff)
		{
		case 0:
			printf("Turned off Rx Echo Cancel\n");
			break;
		case 1:
			printf("Turned on Rx Echo Cancel\n");
			break;
		default:
			printf("Invalid parameter\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id */
