/*
 * digio.c
 * User mode program to read or write the digital I/O pins
 *
 * The upper nibble of the data contains the values for the pins.  They decode to this:
 *
 *   0x10 = Digital Output 1
 *   0x20 = Digital Output 2
 *   0x40 = Digital Input 1
 *   0x80 = Digital Input 2
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	struct rwreg rw;

	printf("\n");

	rw.rwselect=atoi(argv[2]);

	if( (argc!=3) && (argc!=4) )
	{
		printf("usage: %s device rw [data] \n", argv[0]);
		printf("rw: 0 = read 1 = write\n");
		printf("data: 0x10 = DigiOut1 = high\n");
		printf("data: 0x20 = DigiOut2 = high\n");
		exit(1);
	}
	if (rw.rwselect)	//write
	{
		if(argc!=4)
		{
			printf("write usage: %s device rw data \n", argv[0]);
			printf("rw: 0 = read 1 = write\n");
			printf("data: 0x10 = DigOut1 = high\n");
			printf("data: 0x20 = DigOut2 = high\n");
			exit(1);
		}
		sscanf(argv[3],"%lx",&(rw.data));
		rw.address=0;
	}
	else	//read
	{
		if(argc!=3)
		{
			printf("read usage: %s device rw \n", argv[0]);
			printf("rw: 0 = read 1 = write\n");
			exit(1);
		}
		rw.data=0;
		rw.address=0;
	}
	
	printf("rwreg: Opening %s device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}
	if(ioctl(fc,FC_DIG_IO,&rw)==-1) 
	{
		perror(NULL);
	}
	else
	{
		if(rw.rwselect)	//write
		{
			if(rw.data&0x10)
				printf("digio: Set DigOut1 to 1\n");
			else
				printf("digio: Set DigOut1 to 0\n");
			if(rw.data&0x20)
				printf("digio: Set DigOut2 to 1\n");
			else
				printf("digio: Set DigOut2 to 0\n");
		}
		else	//read
		{
			if(rw.data&0x40)
				printf("digio: DigIn1 is 1\n");
			else
				printf("digio: DigIn1 is 0\n");
			if(rw.data&0x80)
				printf("digio: DigIn2 is 1\n");
			else
				printf("digio: DigIn2 is 0\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id$ */
