/*
 * setsample.c
 * User mode program to set the sampling rate.  Sampling determines the number
 * of times a data bit is sampled.  It can be set to either 8X or 16X on a per-
 * port basis.  It is used in conjunction with the clock generator frequency to
 * determine the maximum attainable bit rate.  If your bit rate is less than 
 * 3.125 Mbit/sec you should use 16X sampling.  8X sampling is necessary to 
 * attain rates greater than 3.125 Mbit/sec.
 *
 * Default: 16X
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	int onoff;

	if(argc!=3)
	{
		printf("usage: %s device onoff\n", argv[0]);
		printf("onoff: 0=off 1=on\n");
		exit(1);
	}
	onoff = atoi(argv[2]);

	printf("setsample: Opening \"%s\" device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}
	if(ioctl(fc,FC_SET_SAMPLING,&onoff)==-1) 
	{
		perror(NULL);
	}
	else
	{
		switch(onoff)
		{
		case 0:
			printf("setsample: Switching to 16X sampling\n");
			break;
		case 1:
			printf("setsample: Switching to 8X sampling\n");
			break;
		default:
			printf("setsample: Invalid parameter!\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id$ */
