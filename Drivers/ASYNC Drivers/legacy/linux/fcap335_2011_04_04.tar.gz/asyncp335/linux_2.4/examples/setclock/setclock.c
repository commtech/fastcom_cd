/* 
 * setclock.c
 * User mode program to set the frequency of the onboard clock generator-ICS307.
 * Use to change baud rate.  See README for details.
 * The clock generator can output a minimum of 6MHz and the UART can accept a 
 * maximum frequency of 50MHz.
 *
 * Note: Changing the clock frequency will affect all ports on a single board.
 *
 * Default: 14.7456 MHz
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	unsigned long desfreq;
	unsigned long temp;

	if(argc!=3)
	{
		printf("usage: %s device frequency \n", argv[0]);
		exit(1);
	}
	desfreq = atol(argv[2]);
	if( (desfreq<6000000)||(desfreq>50000000) )
	{
		printf("setclock: Clock out of range 6MHz <= Clock <= 50MHz\n");
		exit(1);
	}
	temp = desfreq;

	printf("setclock: Opening %s device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}

	if(ioctl(fc,FC_SET_CLOCK,&desfreq)==-1) 
	{
		perror(NULL);
	}
	else
	{
		printf("setclock: Actual clock set to %d Hz\n",desfreq);
		if(temp!=desfreq)
		{
			printf("setclock: A deviation of 2.5%% is generally acceptable for asynchronous serial communications.\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id$ */
