/* 
 * 485txen.c
 * User mode program to change 485 transmitter enable feature.  In some 485
 * networks, it is necessary for a transmitter to turn off when not sending, 
 * instead of driving the line.  This function will disable the transmitter 
 * following the last stop bit of the last character that has been sent.
 * 
 * This is accomplished in hardware; it will not hurt performance.
 *
 * Note1: This setting affects only the selected port.
 * Note2: Auto 485 must be enabled to use this feature.
 *
 * Default: Off
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	int onoff;

	if(argc!=3)
	{
		printf("usage: %s device onoff\n", argv[0]);
		printf("onoff: 0 = off 1 = on\n");
		exit(1);
	}

	onoff = atoi(argv[2]);

	printf("485txen: Opening \"%s\" device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}
	
	if(ioctl(fc,FC_485_TX_ENABLE,&onoff)==-1) 
	{
		perror(NULL);
	}
	else
	{
		switch(onoff)
		{
		case 0:
			printf("485txen: Turning off 485 Tx Enable\n");
			break;
		case 1:
			printf("485txen: Turning on 485 Tx Enable\n");
			break;
		default:
			printf("485txen: Invalid parameter\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id$ */
