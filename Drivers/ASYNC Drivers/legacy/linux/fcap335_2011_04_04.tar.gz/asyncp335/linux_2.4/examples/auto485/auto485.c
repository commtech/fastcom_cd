/* 
 * auto485.c
 * User mode program to enable hardware Auto 485 direction control.  The UART
 * will automatically de-assert RTS following the last stop bit of the last
 * character that has been transmitted.  This is accomplished in hardware; it 
 * will not hurt performance.
 * 
 * Note: This setting affects only the selected port.
 *
 * Default: Off
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "../../fcap_335.h"

int main(int argc, char * argv[])
{
	int fc = -1;
	int onoff;

	if(argc!=3)
	{
		printf("usage: %s device onoff\n", argv[0]);
		printf("onoff: 0=off 1=on\n");
		exit(1);
	}

	onoff = atol(argv[2]);

	printf("auto485: Opening \"%s\" device node.\n",argv[1]);

	fc = open(argv[1],O_RDWR);
	if(fc == -1)
	{
		perror(NULL);
		exit(1);
	}

   if(ioctl(fc,FC_AUTO_485,&onoff)==-1) 
	{
		perror(NULL);
	}
	else
	{
		switch(onoff)
		{
		case 0:
			printf("auto485: Turned off Auto 485\n");
			break;
		case 1:
			printf("auto485: Turned on Auto 485\n");
			break;
		default:
			printf("auto485: Invalid parameter\n");
		}
	}

	close(fc);
	return 0;
}

/* $Id$ */
