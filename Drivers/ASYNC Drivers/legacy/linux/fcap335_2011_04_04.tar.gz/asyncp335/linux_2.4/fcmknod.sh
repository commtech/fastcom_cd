#!/bin/bash
MAXPORTS=32
TTYNAME=ttyFC
CUNAME=cufc
port=0
portname=0
tty_major=`cat /proc/devices | awk "\\$2==\"${TTYNAME}\" {print \\$1}"`
cu_major=`cat /proc/devices | awk "\\$2==\"${CUNAME}\" {print \\$1}"`
echo
echo "Fastcom Asynchronous PCI-335 Family Multiport Board Make Node Utility."
echo "Making $MAXPORTS dev nodes for Fastcom ports by default: /dev/${TTYNAME}${port} - /dev/${TTYNAME}1F"
echo
while [ $port -lt $MAXPORTS ]
do
        [ -c /dev/$TTYNAME$portname ] && rm -f /dev/$TTYNAME$portname
        [ -c /dev/$CUNAME$portname ] && rm -f /dev/$CUNAME$portname
                                                                                
#        echo /dev/$TTYNAME$portname /dev/$CUNAME$portname $port 
        mknod /dev/$TTYNAME$portname c $tty_major $port
        mknod /dev/$CUNAME$portname c $cu_major $port
                                                                                
        chmod a+wx /dev/$TTYNAME$portname
        chmod a+wx /dev/$CUNAME$portname
                                                                                
        port=`expr $port + 1`
	portname=$port
	portname=$(echo "$portname 16 o p" | dc)
done

# $Id$
