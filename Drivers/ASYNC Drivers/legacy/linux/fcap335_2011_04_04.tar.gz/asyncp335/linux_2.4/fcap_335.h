#define PCI_VENDOR_ID_COMMTECH	0x18f7
#define PCI_DEVICE_ID_422_4	0x0002
#define PCI_DEVICE_ID_422_2	0x0004
#define PCI_DEVICE_ID_232_4	0x000a
#define FC_MAJOR 250	//change this number if necessary to an empty major

struct triggers 
{
	int rx;
	int tx;
};

struct rwreg 
{
	int rwselect;
	int address;
	int data;
};

struct fc_port_table
{
	int first;
	int portnum;
};

#define FC_SET_CLOCK		_IOWR(FIOQSIZE+1,0, unsigned long)
#define FC_485_TX_ENABLE	_IOR(FIOQSIZE+2,0, int)
#define FC_RX_ECHO_CANCEL	_IOR(FIOQSIZE+3,0, int)
#define FC_AUTO_485		_IOR(FIOQSIZE+4,0, int)
#define FC_SET_FIFO_TRIG	_IOR(FIOQSIZE+5,0, int)
#define FC_SET_SAMPLING		_IOR(FIOQSIZE+6,0, int)
#define FC_RW_REGISTER		_IOWR(FIOQSIZE+7,0, struct rwreg)
#define FC_DIG_IO		_IOWR(FIOQSIZE+8,0,struct rwreg)

/* $Id$ */
