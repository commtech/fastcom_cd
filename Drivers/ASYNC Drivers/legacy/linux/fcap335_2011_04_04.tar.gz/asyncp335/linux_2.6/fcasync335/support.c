/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * support.c -- misc internal support functions for the Fastcom async pci module
 *
 ******************************************************/

/* $Id$ */

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#ifndef __KERNEL__
#  define __KERNEL__
#endif
#ifndef MODULE
#  define MODULE
#endif

#define __NO_VERSION__
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif
#include <linux/module.h> /* get MOD_DEC_USE_COUNT, not the version string */
#include <linux/version.h> /* need it for conditionals in scull.h */

#include <linux/kernel.h> /* printk() */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
#include <linux/slab.h>
#else
#include <linux/malloc.h> /* kmalloc() */
#endif
#include <linux/vmalloc.h>
#include <linux/fs.h>     /* everything... */
#include <linux/proc_fs.h>
#include <linux/errno.h>  /* error codes */
#include <linux/types.h>  /* size_t */
#include <linux/fcntl.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/pci.h>
#include <asm/segment.h>  /* memcpy to/from fs */
#include <asm/system.h>   /* cli(), *_flags */
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/atomic.h>
#include <asm/div64.h>
#include <linux/delay.h>
#include "fcasync.h"        /* local definitions */

// Function name	: GetICS307Bits
// Description	    : Function takes desired frequency as a unsigned long and returns the best
//					  programming bit stream to achieve that frequency on the ICS307 clock generator.
// Return type		: unsigned long 
// Argument         : DOUBLE desired
int GetICS307Bits(unsigned long desired,unsigned long *bits,unsigned long *actual)
{
	unsigned long bestVDW=1;	//Best calculated VCO Divider Word
	unsigned long bestRDW=1;	//Best calculated Reference Divider Word
	unsigned long bestOD=1;		//Best calculated Output Divider
	unsigned long result=0;
	unsigned long vdw=1;		//VCO Divider Word
	unsigned long rdw=1;		//Reference Divider Word
	unsigned long od=1;			//Output Divider
	unsigned long lVDW=1;		//Lowest vdw
	unsigned long lRDW=1;		//Lowest rdw
	unsigned long lOD=1;		//Lowest OD
	unsigned long hVDW=1;		//Highest vdw
	unsigned long hRDW=1;		//Highest rdw
	unsigned long hOD=1;		//Highest OD
	
	unsigned long hi;			//initial range freq Max
	unsigned long low;			//initial freq range Min
	unsigned long check;		//Calculated clock
	unsigned long clk1;			//Actual clock 1 output
	unsigned long inFreq=18432000;	//Input clock frequency
	unsigned long range1=0;		//Desired frequency range limit per ics307 mfg spec.
	unsigned long range2=0;		//Desired frequency range limit per ics307 mfg spec.
	long long n,n2;
	int odskip=0;

	while ((desired < 6000000 )||(desired>50000000))
	{
		if (desired < 6000000 )
		{
			return -1;
		}
		else
		{
			return -2;
		}
	}
	hi=(desired+(desired/10));
	low=(desired-(desired/10));
//	printf("Hi = %lf  Low = %lf \n",hi, low);
	od = 2;
	while (od <= 10)
	{
                switch(od)
                {
                case 2:
                        if(desired>180000000)
                                odskip=1;
                        break;
                case 3:
                        if(desired>120000000)
                                odskip=1;
                        break;
                case 4: if(desired>90000000)
                                odskip=1;
                        break;
                case 5:
                        if(desired>72000000)
                                odskip=1;
                        break;
                case 6:
                        if(desired>60000000)
                                odskip=1;
                        break;
                case 7:
                        if(desired>50000000)
                                odskip=1;
                        break;
                case 8:
                        if(desired>45000000)
                                odskip=1;
                        break;
                case 9:
                        odskip=1;
                case 10:
                        if(desired>36000000)
                                odskip=1;
                        break;
                default:
                        printk("Case 1 Invalid OD = %ld.\n",od);
                        return -1;
                }
		rdw = 1;
		while ( (rdw <= 127) && (odskip==0) )
		{
			vdw = 4;
			while (vdw <= 511)
			{
			n = (long long)inFreq * 2 * ((long long)vdw+8);
			n2 = do_div(n,(((rdw+2)*od)));
				check = (unsigned long)(n);
//				check = (unsigned long)(( (((uint64_t)inFreq * 2)* ((uint64_t)vdw + 8)) / (((rdw + 2)*od)))  );	//calculate a check frequency
			n = (long long)inFreq * 2 * ((long long)vdw+8);
			n2 = do_div(n,((rdw+2)*10));
				range1 = (unsigned long)(n);
//				range1 = (unsigned long)(((uint64_t)inFreq * 2 * ((uint64_t)vdw + 8)) / ((rdw + 2)*10));
			n = (long long)inFreq;
			n2 = do_div(n,((rdw+2)*10));
				range2 = (unsigned long)(n);
//				range2 = (unsigned long)((uint64_t)inFreq / ((rdw + 2)*10));
				if ( ((range1) > 6000000) && ((range1) < 36000000) && ((range2) > 20000) )
				{
//if(check<7000000)DbgPrint("check:%d, range1:%d, range2,%d\r\n",check,range1,range2);

					if (check == low)
					{
//DbgPrint("L=rdw:%d,vdw:%d,od:%d,freq:%d\r\n",rdw,vdw,od,check);
						if (lRDW > rdw)
						{
							lVDW=vdw;
							lRDW=rdw;
							lOD=od;
							low=check;
						}
						else if ((lRDW == rdw) && (lVDW < vdw))
						{
							lVDW=vdw;
							lRDW=rdw;
							lOD=od;
							low=check;
						}
					}
					else if (check == hi)
					{
//DbgPrint("H=rdw:%d,vdw:%d,od:%d,freq:%d\r\n",rdw,vdw,od,check);
						if (hRDW > rdw)
						{
							hVDW=vdw;
							hRDW=rdw;
							hOD=od;
							hi=check;
						}
						else if ((hRDW == rdw) && (hVDW < vdw))
						{
							hVDW=vdw;
							hRDW=rdw;
							hOD=od;
							hi=check;
						}
					}
					if ((check > low) && (check < hi))		//if difference is less than previous difference
					{
//DbgPrint("<>rdw:%d,vdw:%d,od:%d,freq:%d\r\n",rdw,vdw,od,check);
						if ((check) > desired)
						{
							hi=check;
							hVDW=vdw;
							hRDW=rdw;
							hOD=od;
						}
						else 
						{
							low=check;
							lVDW = vdw;
							lRDW = rdw;
							lOD = od;
						}
				}
			}
			vdw++;
		}
		rdw++;
	}
	odskip=0;
	od++;
	if (od==9)
		od++;
	}
	if (((hi) - desired) < (desired - (low)))
	{
		bestVDW=hVDW;
		bestRDW=hRDW;
		bestOD=hOD;
		clk1=hi;
	}
	else
	{
		bestVDW=lVDW;
		bestRDW=lRDW;
		bestOD=lOD;
		clk1=low;
	}
	switch(bestOD)
	{
	case 2:
		result=0x11;
		break;
	case 3:
		result=0x16;
		break;
	case 4:
		result=0x13;
		break;
	case 5:
		result=0x14;
		break;
	case 6:
		result=0x17;
		break;
	case 7:
		result=0x15;
		break;
	case 8:
		result=0x12;
		break;
	case 10:
		result=0x10;
		break;
	default:
printk("ESCCPDRV:ics307clkset..AAAARRRG!!!\r\n");
		return -3;
		
	}
//	range1 = (ULONG)(((__int64)inFreq * 2 * ((__int64)bestVDW + 8)) / (bestRDW + 2));
//	range2 = (inFreq/(bestRDW + 2));
n = (long long)inFreq * 2 * ((long long)bestVDW+8);
n2 = do_div(n,(((bestRDW+2)*bestOD)));
	clk1 = (unsigned long)(n);
//	clk1 = (unsigned long)(( (((uint64_t)inFreq * 2)* ((uint64_t)bestVDW + 8)) / (((bestRDW + 2)*bestOD)))  );	//calculate a check frequency

	result<<=9;
	result|=bestVDW;
	result<<=7;
	result|=bestRDW;
//printk("bits:%lx\n",result);
//printk("act:%ld\n",clk1);
	bits[0] = result;
	actual[0] = clk1;
	return 0;
	
}
//setics307clock, 
//takes ESCC base address in port
//and ics307 programming word in hval
//physically sets clock generator to desired frequency
void setics307clock(Fcasync_Dev *dev, unsigned long hval)
{
	u8 __iomem *p;
	unsigned long tempValue = 0;
	int i=0;
	unsigned char data=0;
	unsigned char savedval;
	p = ioremap(pci_resource_start(dev->pdev,0),pci_resource_len(dev->pdev,0));

	savedval = readb(p+0x90);
	
	writeb((unsigned char)tempValue,p+0x90);

	tempValue = (hval & 0x00ffffff);
//	printf("tempValue = 0x%X\n",tempValue);


	for(i=0;i<24;i++)
	{
		//data bit set
		if ((tempValue & 0x800000)!=0) 
		{
		data = 1;
//			printf("1");
//		data <<=8;
		}
		else 
		{
			data = 0;
//			printf("0");
		}
		writeb(data,p+0x90);
		udelay(10);

		//clock high, data still there
		data |= 0x02;
		writeb(data,p+0x90);
		udelay(10);
		//clock low, data still there
		data &= 0x01;
		writeb(data,p+0x90);
		udelay(10);

		tempValue<<=1;
	}
//	printf("\n");

	data = 0x4;		//strobe on
	writeb(data,p+0x90);
	udelay(10);
	data = 0x0000;		//all off
	writeb(data,p+0x90);
	udelay(10);

	writeb((unsigned char)(savedval&0xF8),p+0x90);	//force sdta,sclk,sstb to 0
	iounmap(p);

}	//void set_clock_generator_307(unsigned long hval)


