/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * setfreq.c -- user utility to change base frequency of a Fastcom async pci 335 card
 *
 ******************************************************/

/* $Id$ */

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int main(int argc,char *argv[])
{
int fd;
unsigned long frequency;
if(argc<3)
{
printf("usage:%s /dev/fcasyncX frequency\n",argv[0]);
exit(1);
}
frequency = atol(argv[2]);
if((frequency<6000000)||(frequency>50000000))
{
printf("frequency out of range, (6MHz to 50Mhz)\n");
exit(1);
}

fd = open(argv[1],O_RDWR);
if(fd!=-1)
{
if(ioctl(fd,FCASYNC_SET_FREQ,&frequency)==0)
{
printf("%s set to %ld\n",argv[1],frequency);
printf("if you want the serial settings to work correctly you need to\n");
printf("modify the 8250_pci.c file to reflect this frequency setting\n");
printf("the default value in 8250_pci.c is 1152000 (which reflects\n");
printf("the reference frequency of 18.432MHz)\n");
printf("If you do not change the value in 8250_pci.c then the values\n");
printf("set for baud rates will be scaled by a factor of %.4f\n",(double)frequency/18432000.0);

}
else printf("error setting frequency!\n");
}
else 
{
printf("cannot open %s\n",argv[1]);
exit(1);
}
}
