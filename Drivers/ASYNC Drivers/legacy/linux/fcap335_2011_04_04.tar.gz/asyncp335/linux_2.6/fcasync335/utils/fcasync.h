/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * fcasync.h -- header file for Fastcom async pci module
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/
typedef struct fifo_control
{
  unsigned char port;
  unsigned char data;
} fifocr;

typedef unsigned long status_t;
 /* Ioctl definitions
 */

/* Use 'k' as magic number */
#define FCASYNC_IOC_MAGIC  'k'
#define FCASYNC_SET_FREQ       _IOW(FCASYNC_IOC_MAGIC,1,status_t)
#define FCASYNC_SET_RXECHO   _IOW(FCASYNC_IOC_MAGIC,2,status_t)
#define FCASYNC_SET_AUTO485    _IOW(FCASYNC_IOC_MAGIC,3,status_t)
#define FCASYNC_SET_SAMPLING   _IOW(FCASYNC_IOC_MAGIC,4,status_t)
#define FCASYNC_SET_TX_TRIG    _IOW(FCASYNC_IOC_MAGIC,5,status_t)
#define FCASYNC_SET_RX_TRIG    _IOW(FCASYNC_IOC_MAGIC,6,status_t)
#define FCASYNC_SET_RTSCTS     _IOW(FCASYNC_IOC_MAGIC,7,status_t) // JRD
#define FCASYNC_SET_RTS     _IOW(FCASYNC_IOC_MAGIC,8,status_t) 
#define FCASYNC_GET_CTS     _IOW(FCASYNC_IOC_MAGIC,9,status_t) 
#define FCASYNC_SET_DTR     _IOW(FCASYNC_IOC_MAGIC,10,status_t) 
#define FCASYNC_GET_DSR     _IOW(FCASYNC_IOC_MAGIC,11,status_t)
#define FCASYNC_SET_DTRDSR     _IOW(FCASYNC_IOC_MAGIC,12,status_t) // JRD

#define FCASYNC_IOC_MAXNR 12



