/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * ioctl.c -- ioctl function for Fastcom async pci module
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#ifndef __KERNEL__
#  define __KERNEL__
#endif
#ifndef MODULE
#  define MODULE
#endif

#define __NO_VERSION__
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif
#include <linux/module.h>	/* get MOD_DEC_USE_COUNT, not the version string */
#include <linux/version.h>	/* need it for conditionals in scull.h */
#include <linux/kernel.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
#include <linux/slab.h>
#else
#include <linux/malloc.h>	/* kmalloc() */
#endif
#include <linux/vmalloc.h>
#include <linux/fs.h>		/* everything... */
#include <linux/proc_fs.h>
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/fcntl.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <asm/segment.h>	/* memcpy to/from fs */
#include <asm/system.h>		/* cli(), *_flags */
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/atomic.h>
#include "fcasync.h"		/* local definitions */

/*
 * The ioctl() implementation
 */

#if LINUX_VERSION_CODE >= VERSION_CODE(2, 6, 11)
long fcasync_ioctl (struct file *filp,
		   unsigned int cmd, unsigned long arg)
#else
int fcasync_ioctl (struct inode *inode, struct file *filp,
                 unsigned int cmd, unsigned long arg)
#endif
{
  Fcasync_Dev *dev;
  u8 oldval;

  dev = filp->private_data;
  /*
   * extract the type and number bitfields, and don't decode
   * wrong cmds: return EINVAL before verify_area()
   */
  if (_IOC_TYPE (cmd) != FCASYNC_IOC_MAGIC)
    return -EINVAL;
  if (_IOC_NR (cmd) > FCASYNC_IOC_MAXNR)
    return -EINVAL;
  /*
   * the direction is a bitmask, and VERIFY_WRITE catches R/W
   * transfers. `Type' is user-oriented, while
   * verify_area is kernel-oriented, so the concept of "read" and
   * "write" is reversed
   */
  switch (cmd)
    {
    case FCASYNC_SET_FREQ:
      if (dev->uartbase == 0)
	return -ENODEV;

      if (copy_from_user
	  (&dev->freq, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;

      if (1)
	{
	  unsigned long cbits;
	  unsigned long actualc;
	  if (GetICS307Bits (dev->freq, &cbits, &actualc) == 0)
	    {
	      setics307clock (dev, cbits);
	    }
	}
      break;

   case FCASYNC_SET_RXECHO:
      if (dev->uartbase == 0)
	return -ENODEV;
      if (copy_from_user
	  (&dev->rxecho, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;
      if ((dev->boardtype == FC4222) || (dev->boardtype == FC4224))
	{
	  u8 __iomem *p;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  oldval = readb (p + 0x90);
          if(dev->rxecho)
          {
            oldval |= 0x80;
            writeb (oldval, p + 0x90);
          }
          else
          {
            oldval &= 0x7f;
            writeb (oldval, p + 0x90);
          }
	  udelay (20);
	  iounmap (p);
	}
      break;

    case FCASYNC_SET_AUTO485:
      if (dev->uartbase == 0)
	return -ENODEV;
      if (copy_from_user
	  (&dev->auto485en, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;
      if ((dev->boardtype == FC4222) || (dev->boardtype == FC4224))
	{
	  u8 __iomem *p;
	  unsigned oldFCTR = 0, oldMCR = 0, oldMP = 0;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  oldMP = readb (p + 0x90);
	  oldFCTR = readb (p + 0x08);
	  oldMCR = readb (p + 0x04); // JRD
	  if (dev->auto485en & 0x01)	//set port 0
	    {
              oldMP &= 0xf7;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 0
	    {
              oldMP |= 0x08;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0x08);
	  writeb (oldMCR, p + 0x04);

	  oldFCTR = readb (p + 0x208);
	  oldMCR = readb (p + 0x204);
	  if (dev->auto485en & 0x02)	//set port 1
	    {
              oldMP &= 0xef;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 1
	    {
              oldMP |= 0x10;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0x208);
	  writeb (oldMCR, p + 0x204); 

	  oldFCTR = readb (p + 0x408);
	  oldMCR = readb (p + 0x404);
	  if (dev->auto485en & 0x04)	//set port 2
	    {
              oldMP &= 0xdf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 2
	    {
              oldMP |= 0x20;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0x408);
	  writeb (oldMCR, p + 0x404);

	  oldFCTR = readb (p + 0x608);
	  oldMCR = readb (p + 0x604); 
	  if (dev->auto485en & 0x08)	//set port 3
	    {
              oldMP &= 0xbf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 3
	    {
              oldMP |= 0x40;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0x608);
	  writeb (oldMCR, p + 0x604);

	  oldFCTR = readb (p + 0x808);
	  oldMCR = readb (p + 0x804); 
       	  if (dev->auto485en & 0x10)	//set port 4
	    {
              oldMP &= 0xbf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 4
	    {
              oldMP |= 0x40;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0x808);
	  writeb (oldMCR, p + 0x804);

	  oldFCTR = readb (p + 0xa08);
	  oldMCR = readb (p + 0xa04); 
	  if (dev->auto485en & 0x20)	//set port 5
	    {
              oldMP &= 0xbf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 5
	    {
              oldMP |= 0x40;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0xa08);
	  writeb (oldMCR, p + 0xa04);

	  oldFCTR = readb (p + 0xc08);
	  oldMCR = readb (p + 0xc04); 
	  if (dev->auto485en & 0x40)	//set port 6
	    {
              oldMP &= 0xbf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 6
	    {
              oldMP |= 0x40;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0xc08);
	  writeb (oldMCR, p + 0xc04);

	  oldFCTR = readb (p + 0xe08);
	  oldMCR = readb (p + 0xe04); 
	  if (dev->auto485en & 0x80)	//set port 7
	    {
              oldMP &= 0xbf;
	      oldFCTR |= 0x20;
	      oldMCR |= 0x03;
	    }
	  else			//reset port 7
	    {
              oldMP |= 0x40;
	      oldFCTR &= 0xdf;
	      oldMCR &= 0xfc;
	    }
          writeb (oldMP, p + 0x90);
	  writeb (oldFCTR, p + 0xe08);
	  writeb (oldMCR, p + 0xe04);
   
          udelay (20);
	  iounmap (p);
	}
      break;

    case FCASYNC_SET_SAMPLING:
      if (copy_from_user
	  (&dev->sampling, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;
      else
	{
	  u8 __iomem *p;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  writeb ((dev->sampling) & 0xff, p + 0x88);
          udelay (20);
	  iounmap (p);
	}

      break;

    case FCASYNC_SET_TX_TRIG:
      if (copy_from_user
	  (&dev->TxTrig, (fifocr *) arg, sizeof (fifocr) )) // This copies two unsigned characters from the user, IE fifot[0]=0x01,fifot[1]=0x32
	return -EFAULT;
      else
	{
	  unsigned char oldFCTR;
	  u8 __iomem *p;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  switch (dev->TxTrig.port)
	    {
	    case 0:
	      oldFCTR = readb (p + 0x08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x08);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0x0a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 1:
	      oldFCTR = readb (p + 0x208);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x208);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0x20a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 2:
	      oldFCTR = readb (p + 0x408);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x408);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0x40a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 3:
	      oldFCTR = readb (p + 0x608);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x608);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0x60a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 4:
	      oldFCTR = readb (p + 0x808);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x808);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0x80a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 5:
	      oldFCTR = readb (p + 0xa08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xa08);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0xa0a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 6:
	      oldFCTR = readb (p + 0xc08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xc08);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0xc0a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    case 7:
	      oldFCTR = readb (p + 0xe08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xe08);
	      if ((dev->TxTrig.data > 0) && (dev->TxTrig.data < 64))
		writeb (dev->TxTrig.data, p + 0xe0a);
	      else
		printk ("fcasync335: Error: TxTrigger should be 0<, 64>\n");

	      break;
	    default:
		printk("fcasync335: Error: Port should be 0-7\n");
	    }
          udelay (20);
	  iounmap (p);	
        }

      break;

    case FCASYNC_SET_RX_TRIG:
      if (copy_from_user
	  (&dev->RxTrig, (fifocr *) arg, sizeof (fifocr) ))
	return -EFAULT;
      else
	{
		unsigned char oldFCTR;
	  u8 __iomem *p;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  switch (dev->RxTrig.port)
	    {
	    case 0:
	      oldFCTR = readb (p + 0x08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x08);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0x0b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 1:
	      oldFCTR = readb (p + 0x208);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x208);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0x20b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 2:
	      oldFCTR = readb (p + 0x408);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x408);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0x40b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 3:
	      oldFCTR = readb (p + 0x608);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x608);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0x60b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 4:
	      oldFCTR = readb (p + 0x808);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0x808);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0x80b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 5:
	      oldFCTR = readb (p + 0xa08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xa08);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0xa0b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 6:
	      oldFCTR = readb (p + 0xc08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xc08);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0xc0b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    case 7:
	      oldFCTR = readb (p + 0xe08);
	      oldFCTR &= 0xf0;
	      oldFCTR |= 0xc0;
	      writeb (oldFCTR, p + 0xe08);
	      if ((dev->RxTrig.data > 0) && (dev->RxTrig.data < 64))
		writeb (dev->RxTrig.data, p + 0xe0b);
	      else
		printk ("fcasync335: Error: RxTrigger should be 0<, 64>\n");

	      break;
	    default:
		printk("fcasync335: Error: Port should be 0-7\n");
	    }
          udelay (20);
	  iounmap (p);
	}

      break;

    case FCASYNC_SET_RTSCTS:
	{
      if (dev->uartbase == 0)
	return -ENODEV;
      if (copy_from_user
	  (&dev->rtscts, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;
	  u8 __iomem *p;
	  unsigned oldMCR = 0, oldEFR = 0;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  oldMCR = readb (p + 0x04);
	  oldEFR = readb (p + 0x09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x09); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0x04);
	  if (dev->rtscts & 0x0001)	//set port 0 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 0 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x02)	//set port 0 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 0 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x09);

	  oldMCR = readb (p + 0x204);
	  oldEFR = readb (p + 0x209);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x209); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0x204);
	  if (dev->rtscts & 0x04)	//set port 1 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 1 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x08)	//set port 1 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 1 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x204);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x209);

	  oldMCR = readb (p + 0x404);
	  oldEFR = readb (p + 0x409);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x409); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0x404);
	  if (dev->rtscts & 0x10)	//set port 2 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 2 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x20)	//set port 2 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 2 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x404);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x409);

	  oldMCR = readb (p + 0x604);
	  oldEFR = readb (p + 0x609);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x609); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0x604);
	  if (dev->rtscts & 0x40)	//set port 3 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 3 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x80)	//set port 3 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 3 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x604);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x609);

	  oldMCR = readb (p + 0x804);
	  oldEFR = readb (p + 0x809);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x809); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0x804);
	  if (dev->rtscts & 0x0100)	//set port 4 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 4 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x0200)	//set port 4 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 4 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x804);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x809);

	  oldMCR = readb (p + 0xA04);
	  oldEFR = readb (p + 0xA09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xA09); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0xA04);
	  if (dev->rtscts & 0x0400)	//set port 5 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 5 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x0800)	//set port 5 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 5 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xA04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xA09);

	  oldMCR = readb (p + 0xC04);
	  oldEFR = readb (p + 0xC09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xC09); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0xC04);
	  if (dev->rtscts & 0x1000)	//set port 6 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 6 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x2000)	//set port 6 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 6 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xC04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xC09);

	  oldMCR = readb (p + 0xE04);
	  oldEFR = readb (p + 0xE09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xE09); 
          oldMCR &= 0xFB;  // This bit should always be 0, so we always set it to 0.
	  writeb (oldMCR, p + 0xE04);
	  if (dev->rtscts & 0x4000)	//set port 7 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 7 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x8000)	//set port 7 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 7 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xE04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xE09);

          udelay (20);
	  iounmap (p);
	}
      break;

    case FCASYNC_SET_DTRDSR:
	{
      if (dev->uartbase == 0)
	return -ENODEV;
      if (copy_from_user
	  (&dev->rtscts, (unsigned long *) arg, sizeof (unsigned long)))
	return -EFAULT;
	  u8 __iomem *p;
	  unsigned oldMCR = 0, oldEFR = 0;
	  p =
	    ioremap (pci_resource_start (dev->pdev, 0),
		     pci_resource_len (dev->pdev, 0));
	  if (p == NULL)
	    {
	      printk ("cannot map memory\n");
	      return -ENOMEM;
	    }
	  oldMCR = readb (p + 0x04);
	  oldEFR = readb (p + 0x09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x09); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0x04);
	  if (dev->rtscts & 0x0001)	//set port 0 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 0 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x02)	//set port 0 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 0 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x09);

	  oldMCR = readb (p + 0x204);
	  oldEFR = readb (p + 0x209);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x209); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0x204);
	  if (dev->rtscts & 0x04)	//set port 1 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 1 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x08)	//set port 1 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 1 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x204);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x209);

	  oldMCR = readb (p + 0x404);
	  oldEFR = readb (p + 0x409);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x409); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0x404);
	  if (dev->rtscts & 0x10)	//set port 2 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 2 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x20)	//set port 2 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 2 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x404);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x409);

	  oldMCR = readb (p + 0x604);
	  oldEFR = readb (p + 0x609);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x609); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0x604);
	  if (dev->rtscts & 0x40)	//set port 3 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 3 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x80)	//set port 3 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 3 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x604);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x609);

	  oldMCR = readb (p + 0x804);
	  oldEFR = readb (p + 0x809);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0x809); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0x804);
	  if (dev->rtscts & 0x0100)	//set port 4 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 4 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x0200)	//set port 4 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 4 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0x804);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0x809);

	  oldMCR = readb (p + 0xA04);
	  oldEFR = readb (p + 0xA09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xA09); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0xA04);
	  if (dev->rtscts & 0x0400)	//set port 5 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 5 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x0800)	//set port 5 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 5 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xA04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xA09);

	  oldMCR = readb (p + 0xC04);
	  oldEFR = readb (p + 0xC09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xC09); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0xC04);
	  if (dev->rtscts & 0x1000)	//set port 6 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 6 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x2000)	//set port 6 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 6 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xC04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xC09);

	  oldMCR = readb (p + 0xE04);
	  oldEFR = readb (p + 0xE09);
	  oldEFR |= 0x10; // Gotta open up the grey bits so we can alter them.
	  writeb (oldEFR, p + 0xE09); 
          oldMCR |= 0x04;  // This bit should always be 1, so we always set it to 1.
	  writeb (oldMCR, p + 0xE04);
	  if (dev->rtscts & 0x4000)	//set port 7 CTS
	    {
	      oldEFR |= 0x80;
	    }
	  else			//reset port 7 CTS
	    {
              oldEFR &= 0x7F;
	    }
	  if (dev->rtscts & 0x8000)	//set port 7 RTS
	    {
	      oldEFR |= 0x40;
	    }
	  else			//reset port 7 RTS
	    {
              oldEFR &= 0xBF;
	    }
	  writeb (oldMCR, p + 0xE04);
	  oldEFR &= 0xEF; // Turn the grey bits back off.
	  writeb (oldEFR, p + 0xE09);

          udelay (20);
	  iounmap (p);
	}
      break;

    case FCASYNC_SET_RTS:
      {
	unsigned oldMCR = 0, datain = 0;
	u8 __iomem *p;

	if (copy_from_user(&datain, (unsigned long *) arg, sizeof (unsigned long)))
	  return -EFAULT;
	p = ioremap (pci_resource_start (dev->pdev, 0),pci_resource_len (dev->pdev, 0));
	if (p == NULL)
	  {
	    printk ("cannot map memory\n");
	    return -ENOMEM;
	  }
	//port0
	oldMCR = readb (p + 0x004);
	if(datain & 0x01) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0x004);
	//port1
      	oldMCR = readb (p + 0x204);
	if(datain & 0x02) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0x204);
	//port2
       	oldMCR = readb (p + 0x404);
	if(datain & 0x04) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0x404);
 	//port3
       	oldMCR = readb (p + 0x604);
	if(datain & 0x08) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0x604);
 	//port4
       	oldMCR = readb (p + 0x804);
	if(datain & 0x10) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0x804);
 	//port5
       	oldMCR = readb (p + 0xa04);
	if(datain & 0x20) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0xa04);
 	//port6
       	oldMCR = readb (p + 0xc04);
	if(datain & 0x40) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0xc04);
 	//port7
       	oldMCR = readb (p + 0xe04);
	if(datain & 0x80) oldMCR |= 0x02; //set RTS
	else oldMCR &= 0xFD; //clear RTS
	writeb(oldMCR, p +0xe04);
      }
      break;

    case FCASYNC_GET_CTS:
      {
	unsigned oldMSR = 0, dataout = 0;
	u8 __iomem *p;

	p = ioremap (pci_resource_start (dev->pdev, 0),pci_resource_len (dev->pdev, 0));
	if (p == NULL)
	  {
	    printk ("cannot map memory\n");
	    return -ENOMEM;
	  }
	//port0
	oldMSR = readb (p + 0x006);
	if(oldMSR & 0x10) dataout|=0x01; //CTS set
	else dataout&=0xFE; //CTS cleared
	//port1
	oldMSR = readb (p + 0x206);
	if(oldMSR & 0x10) dataout|=0x02; //CTS set
	else dataout&=0xFD; //CTS cleared
	//port2
	oldMSR = readb (p + 0x406);
	if(oldMSR & 0x10) dataout|=0x04; //CTS set
	else dataout&=0xFB; //CTS cleared
	//port3
	oldMSR = readb (p + 0x606);
	if(oldMSR & 0x10) dataout|=0x08; //CTS set
	else dataout&=0xF7; //CTS cleared
	//port4
	oldMSR = readb (p + 0x806);
	if(oldMSR & 0x10) dataout|=0x10; //CTS set
	else dataout&=0xEF; //CTS cleared
	//port5
	oldMSR = readb (p + 0xa06);
	if(oldMSR & 0x10) dataout|=0x20; //CTS set
	else dataout&=0xDF; //CTS cleared
	//port6
	oldMSR = readb (p + 0xc06);
	if(oldMSR & 0x10) dataout|=0x40; //CTS set
	else dataout&=0xBF; //CTS cleared
	//port7
	oldMSR = readb (p + 0xe06);
	if(oldMSR & 0x10) dataout|=0x80; //CTS set
	else dataout&=0x7F; //CTS cleared

        if (copy_to_user((unsigned long *) arg, &dataout, sizeof (unsigned long)))
	  return -EFAULT;
      }
      break;

    case FCASYNC_SET_DTR:
      {
	unsigned oldMCR = 0, datain = 0;
	u8 __iomem *p;

	if (copy_from_user(&datain, (unsigned long *) arg, sizeof (unsigned long)))
	  return -EFAULT;
	p = ioremap (pci_resource_start (dev->pdev, 0),pci_resource_len (dev->pdev, 0));
	if (p == NULL)
	  {
	    printk ("cannot map memory\n");
	    return -ENOMEM;
	  }
	//port0
	oldMCR = readb (p + 0x004);
	if(datain & 0x01) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0x004);
	//port1
      	oldMCR = readb (p + 0x204);
	if(datain & 0x02) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0x204);
	//port2
       	oldMCR = readb (p + 0x404);
	if(datain & 0x04) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0x404);
 	//port3
       	oldMCR = readb (p + 0x604);
	if(datain & 0x08) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0x604);
 	//port4
       	oldMCR = readb (p + 0x804);
	if(datain & 0x10) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0x804);
 	//port5
       	oldMCR = readb (p + 0xa04);
	if(datain & 0x20) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0xa04);
 	//port6
       	oldMCR = readb (p + 0xc04);
	if(datain & 0x40) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0xc04);
 	//port7
       	oldMCR = readb (p + 0xe04);
	if(datain & 0x80) oldMCR |= 0x01; //set DTR
	else oldMCR &= 0xFE; //clear DTR
	writeb(oldMCR, p +0xe04);
      }
      break;

    case FCASYNC_GET_DSR:
      {
	unsigned oldMSR = 0, dataout = 0;
	u8 __iomem *p;

	p = ioremap (pci_resource_start (dev->pdev, 0),pci_resource_len (dev->pdev, 0));
	if (p == NULL)
	  {
	    printk ("cannot map memory\n");
	    return -ENOMEM;
	  }
	//port0
	oldMSR = readb (p + 0x006);
	if(oldMSR & 0x20) dataout|=0x01; //DSR set
	else dataout&=0xFE; //DSR cleared
	//port1
	oldMSR = readb (p + 0x206);
	if(oldMSR & 0x20) dataout|=0x02; //DSR set
	else dataout&=0xFD; //DSR cleared
	//port2
	oldMSR = readb (p + 0x406);
	if(oldMSR & 0x20) dataout|=0x04; //DSR set
	else dataout&=0xFB; //DSR cleared
	//port3
	oldMSR = readb (p + 0x606);
	if(oldMSR & 0x20) dataout|=0x08; //DSR set
	else dataout&=0xF7; //DSR cleared
	//port4
	oldMSR = readb (p + 0x806);
	if(oldMSR & 0x20) dataout|=0x10; //DSR set
	else dataout&=0xEF; //DSR cleared
	//port5
	oldMSR = readb (p + 0xa06);
	if(oldMSR & 0x20) dataout|=0x20; //DSR set
	else dataout&=0xDF; //DSR cleared
	//port6
	oldMSR = readb (p + 0xc06);
	if(oldMSR & 0x20) dataout|=0x40; //DSR set
	else dataout&=0xBF; //DSR cleared
	//port7
	oldMSR = readb (p + 0xe06);
	if(oldMSR & 0x20) dataout|=0x80; //DSR set
	else dataout&=0x7F; //DSR cleared

        if (copy_to_user((unsigned long *) arg, &dataout, sizeof (unsigned long)))
	  return -EFAULT;
      }
      break;

    default:			/* redundant, as cmd was checked against MAXNR */
      return -EINVAL;
    }
  return 0;

}
