/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * fcasync.h -- header file for Fastcom async pci module
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/
#include <linux/poll.h>
#include <linux/ioctl.h>

/* version dependencies have been confined to a separate file */

#define VERSION_CODE(vers,rel,seq) ( ((vers)<<16) | ((rel)<<8) | (seq) )
#include "sysdep.h"

//define if using 2.6 kernel series.--possibly rework with VERSION_CODE, is version code still there in 2.6?
#if  LINUX_VERSION_CODE >= VERSION_CODE(2,6,0)
#define USE_2_6
#include <linux/interrupt.h>
#endif



#ifndef FCASYNC_MAJOR		//dynamic is broken on 2.6? giving 0 doesn't work anymore
#define FCASYNC_MAJOR 0		/* dynamic major by default */
#endif

#define PCI_VENDOR_ID_COMMTECH_FASTCOM 0x18F7
#define PCI_DEVICE_ID_FC4222335 0x0004
#define PCI_DEVICE_ID_FC4224335 0x0002
#define PCI_DEVICE_ID_FC2324335 0x000a
#define PCI_DEVICE_ID_FC2328335 0x000b

#define FC4222 0x0004
#define FC4224 0x0002
#define FC2324 0x000a
#define FC2328 0x000b

#ifndef MAX_FCASYNC_BOARDS
#define MAX_FCASYNC_BOARDS 15	/*  */
#endif



//typedef struct fcasync_clkset
//{
//  unsigned long clockbits;
//  unsigned numbits;
//} clkset;

//typedef struct fcasync_regsingle
//{
//  unsigned long port;		//offset from base address of register to access
//  unsigned char data;		//data to write
//} regsingle;

typedef struct fifo_control
{
  unsigned char port;
  unsigned char data;
} fifocr;


typedef struct Fcasync_Dev
{
//  clkset clock;
  unsigned uartbase;
  unsigned irq;
  unsigned long boardtype;
  unsigned dev_no;	//only needed to check against previous in addboard
  struct pci_dev *pdev;
  unsigned long fcasync_u_count;
  uid_t fcasync_u_owner;
  unsigned long freq;
  unsigned long rxecho;
  unsigned long auto485en;
  unsigned long sampling;
  unsigned long rtscts; // JRD, for RTSCTS
  fifocr TxTrig;
  fifocr RxTrig;
} Fcasync_Dev;

/*
 * Split minors in two parts
 */
#define TYPE(dev)   (MINOR(dev) >> 4)	/* high nibble */
#define NUM(dev)    (MINOR(dev) & 0xf)	/* low  nibble */

/*
 * Different minors behave differently, so let's use multiple fops
 */

extern struct file_operations fcasync_fops;	/* simplest: global */

/*
 * The different configurable parameters
 */
extern int fcasync_major;	/* main.c */
extern int fcasync_nr_devs;
//extern clkset clock;
extern Fcasync_Dev *fcasync_devices;

#if LINUX_VERSION_CODE >= VERSION_CODE(2, 6, 11)
long fcasync_ioctl (struct file *filp,
		   unsigned int cmd, unsigned long arg);
#else
int fcasync_ioctl (struct inode *inode, struct file *filp,
                 unsigned int cmd, unsigned long arg);
#endif
int fcasync_open (struct inode *inode, struct file *filp);
int fcasync_release (struct inode *inode, struct file *filp);
int GetICS307Bits (unsigned long desired, unsigned long *bits,
		   unsigned long *actual);
void setics307clock (Fcasync_Dev * dev, unsigned long hval);

#ifndef min
#  define min(a,b) ((a)<(b) ? (a) : (b))
#endif
typedef unsigned long status_t;
 /* Ioctl definitions
  */

/* Use 'k' as magic number */
#define FCASYNC_IOC_MAGIC  'k'
#define FCASYNC_SET_FREQ       _IOW(FCASYNC_IOC_MAGIC,1,status_t)
#define FCASYNC_SET_RXECHO   _IOW(FCASYNC_IOC_MAGIC,2,status_t)
#define FCASYNC_SET_AUTO485    _IOW(FCASYNC_IOC_MAGIC,3,status_t)
#define FCASYNC_SET_SAMPLING   _IOW(FCASYNC_IOC_MAGIC,4,status_t)
#define FCASYNC_SET_TX_TRIG    _IOW(FCASYNC_IOC_MAGIC,5,status_t)
#define FCASYNC_SET_RX_TRIG    _IOW(FCASYNC_IOC_MAGIC,6,status_t)
#define FCASYNC_SET_RTSCTS     _IOW(FCASYNC_IOC_MAGIC,7,status_t) // JRD
#define FCASYNC_SET_RTS     _IOW(FCASYNC_IOC_MAGIC,8,status_t) 
#define FCASYNC_GET_CTS     _IOW(FCASYNC_IOC_MAGIC,9,status_t) 
#define FCASYNC_SET_DTR     _IOW(FCASYNC_IOC_MAGIC,10,status_t) 
#define FCASYNC_GET_DSR     _IOW(FCASYNC_IOC_MAGIC,11,status_t)
#define FCASYNC_SET_DTRDSR     _IOW(FCASYNC_IOC_MAGIC,12,status_t)  // JRD

#define FCASYNC_IOC_MAXNR 12 
