/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * rtscts.c -- user utility to configure a Fastcom async pci 335 board
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

techsupport@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int
main (int argc, char *argv[])
{
  int fd;
  unsigned datain;
  if (argc != 3)
    {
      printf ("usage:%s /dev/fcasyncX DTR\n", argv[0]);
      printf ("\n");
      printf ("\t0 =>DTR disable\n");
      printf ("\t1 =>DTR enable\n");
      printf ("\tEach bit corresponds to a port on your card.\n\tPort0 is bit 0, Port1 is bit 1, etc.\n");
      printf ("\n");

      exit (1);
    }
  sscanf (argv[2], "%x", &datain);
  fd = open (argv[1], O_RDWR);
  if (fd != -1)
    {
      if (ioctl (fd, FCASYNC_SET_DTR, &datain) == 0)
	{
	}
      else
	printf ("Error setting DTR!\n");
   }
  else
    {
      printf ("Cannot open %s.\n", argv[1]);
      exit (1);
    }
}

