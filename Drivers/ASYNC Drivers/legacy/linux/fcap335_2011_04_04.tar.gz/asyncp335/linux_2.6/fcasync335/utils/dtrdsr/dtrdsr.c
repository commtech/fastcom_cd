/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * rtscts.c -- user utility to configure a Fastcom async pci 335 board
 *
 ******************************************************/

/* $Id$ */

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

techsupport@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int
main (int argc, char *argv[])
{
  int fd;
  unsigned long datain;
  if (argc < 3)
    {
      printf ("usage:%s /dev/fcasyncX dtrdsr\n", argv[0]);
      printf ("\tdtrdsr is accepted as a hex byte and is:\n");
      printf ("\t0=dtr/dsr disable - 1=dtr/dsr enable\n");
      printf ("\n");
      printf ("\tbit0 =>DTR channel 0\n");
      printf ("\tbit1 =>DSR channel 0\n");
      printf ("\tbit2 =>DTR channel 1\n");
      printf ("\tbit3 =>DSR channel 1\n");
      printf ("\tbit4 =>DTR channel 2\n");
      printf ("\tbit5 =>DSR channel 2\n");
      printf ("\tbit6 =>DTR channel 3\n");
      printf ("\tbit7 =>DSR channel 3\n\n");
      printf ("\tbit8 =>DTR channel 4\n");
      printf ("\tbit9 =>DSR channel 4\n");
      printf ("\tbit10 =>DTR channel 5\n");
      printf ("\tbit11 =>DSR channel 5\n");
      printf ("\tbit12 =>DTR channel 6\n");
      printf ("\tbit13 =>DSR channel 6\n");
      printf ("\tbit14 =>DTR channel 7\n");
      printf ("\tbit15 =>DSR channel 7\n");
      printf ("\n");
      printf ("Enable/Disable Automatic DTR Flow Control\n");
      printf ("Enable/Disable Automatic DSR Flow Control\n");

      exit (1);
    }
  sscanf (argv[2], "%lx", &datain);
  fd = open (argv[1], O_RDWR);
  if (fd != -1)
    {
      if (ioctl (fd, FCASYNC_SET_DTRDSR, &datain) == 0)
	{
	  printf ("%s set to 0x%4.4lx\n", argv[1], datain);
	  printf ("dtr ch7 is ");
	  if ((datain & 0x8000) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch7 is ");
	  if ((datain & 0x4000) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch6 is ");
	  if ((datain & 0x2000) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch6 is ");
	  if ((datain & 0x1000) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch5 is ");
	  if ((datain & 0x800) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch5 is ");
	  if ((datain & 0x400) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch4 is ");
	  if ((datain & 0x200) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch4 is ");
	  if ((datain & 0x100) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch3 is ");
	  if ((datain & 0x80) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch3 is ");
	  if ((datain & 0x40) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch2 is ");
	  if ((datain & 0x20) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch2 is ");
	  if ((datain & 0x10) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch1 is ");
	  if ((datain & 0x08) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch1 is ");
	  if ((datain & 0x04) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dtr ch0 is ");
	  if ((datain & 0x02) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("dsr ch0 is ");
	  if ((datain & 0x01) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");

	}
      else
	printf ("Error setting dtr/dsr!\n");
    }
  else
    {
      printf ("Cannot open %s.\n", argv[1]);
      exit (1);
    }
}

