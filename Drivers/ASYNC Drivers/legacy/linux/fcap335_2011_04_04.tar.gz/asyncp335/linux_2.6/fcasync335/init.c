/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * init.c -- init stuff for fastcom async pci module
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

custserv@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#ifndef __KERNEL__
#  define __KERNEL__
#endif
#ifndef MODULE
#  define MODULE
#endif
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif
#include <linux/module.h>
#include <linux/version.h>
MODULE_LICENSE("GPL");
//char kernel_version [] = UTS_RELEASE;

#include <linux/kernel.h> /* printk() */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
#include <linux/slab.h>
#else
#include <linux/malloc.h> /* kmalloc() */
#endif
#include <linux/vmalloc.h>
#include <linux/fs.h>     /* everything... */
#include <linux/errno.h>  /* error codes */
#include <linux/types.h>  /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>        /* O_ACCMODE */
#include <linux/ioport.h>
#include <asm/system.h>   /* cli(), *_flags */
#include <asm/segment.h>  /* memcpy and such */
#include <asm/atomic.h>
#include <linux/string.h>

//#include <linux/config.h>  //for PCI stuff
#include <linux/pci.h>	   //for PCI stuff

#include "fcasync.h"        /* local definitions */

char boardtypes[11][25] = { "",
			"",
			"Fastcom:422/4-PCI-335",
			"",
			"Fastcom:422/2-PCI-335",
			"",
			"",
			"",
			"",
			"",
			"Fastcom:232/4-PCI-335",
			};


int fcasync_major =   FCASYNC_MAJOR;
//clkset clock; //not needed other than for param to ioctl building
Fcasync_Dev *fcasync_devices; /* allocated in init_module */
int fcasync_nr_devs;
struct file_operations *fcasync_fop_array[]={
#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0)
	NULL,			//struct module *owner
#endif
    &fcasync_fops      /* type 0 */
};

//MODULE_AUTHOR("Matt Schulte <matts@commtech-fastcom.com>");
//MODULE_DESCRIPTION("IOCTL Driver for the Fastcom(tm) series async PCI335 adapters");
/*
 * The different file operations
 */
struct file_operations fcasync_fops = {
.owner = THIS_MODULE,
#if LINUX_VERSION_CODE >= VERSION_CODE(2, 6, 11)
  .unlocked_ioctl = fcasync_ioctl,
#else
.ioctl = fcasync_ioctl,
#endif
.open = fcasync_open,
.release = fcasync_release,
};

struct file_operations proc_fops = {
#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0)
	NULL,			//struct module *owner
#endif
    NULL,   //llseek
    NULL,	  //read
    NULL,	  //write
    NULL,         /* readdir */
    NULL,    /* select now poll */
    NULL,	  //ioctl --the workhorse of all this
    NULL,         /*mmap */
    NULL,	  //open
    NULL, 		  //flush
    NULL, //release (close)
    NULL,   //fsync
    NULL,         //fasync
    NULL,         //check media change
    NULL,         //revalidate
    NULL          //lock
};


/*
 * The proc filesystem: function to read an entry
 */

int fcasync_read_procmem(char *buf, char **start, off_t offset, int len, int *unused, void *data)
{
    int i;
    Fcasync_Dev *d;
    #define LIMIT (PAGE_SIZE-80) /* don't print any more after this size */
//note it isn't enforced....??
    len=0;
    for(i=0; i<fcasync_nr_devs; i++) 
	{
	//fill in usefull info here, displayed in /proc/esccdrv via 'cat /proc/esccdev'
        d=&fcasync_devices[i];
        len += sprintf(buf+len,"Dev %i: Base:%x irq:%i type:%s\n",i,d->uartbase, d->irq,boardtypes[d->boardtype]);
//still not sure why sprintfing to buf doesn't fault, we are in kernel space here
//should not it be "put_user'ed to the buffer???
        
    }
    return len;
}
#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0)
static struct proc_dir_entry *proc_fcasync_entry;
#else
struct proc_dir_entry fcasync_proc_entry = {
        0,					/* low_ino: the inode -- dynamic */
        8,					/* Name Length */
        "fcasync335",			/* Entry Name */
        S_IFREG | S_IRUGO,	/* mode_t Mode */
        1,					/* nlink_t nlink */
        0,					/* uid_t uid */
        0,					/* gid_t gid */
        20,					/* ulong Size */
        NULL,				/* struct inode_operations *PTR */
		#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0)
        &fcasync_fops,			/* struct file_operations *PTR */
		#endif
		NULL,				/* get_info_t * */
		#if  LINUX_VERSION_CODE <= VERSION_CODE(2,4,0)
		NULL,
		#endif
		#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0) /* Check Version Number..2.4.0 is not precise */
		NULL,				/* struct module *owner */
		#endif
		NULL,				/* struct proc_dir_entry *next */
		NULL,				/* struct proc_dir_entry *parent */
		NULL,				/* struct proc_dir_entry *subdir */
		NULL,				/* void *data - Pointer to data */
		&fcasync_read_procmem,	/* read_proc_t *read_proc */
		NULL,/* write_proc_t *write_proc */
        					/* atomic_t count - Counter */
        					/* int delete - Delete Flags */
							/* kdev_t rdev */
    };
#endif




/*
 * Finally, the module stuff
 */
#ifdef USE_2_6
static int __init  fcasync_init(void)
#else
int init_module(void)
#endif
{
int result, i;
int index;
unsigned long uartbase[MAX_FCASYNC_BOARDS];//holds all 16C850 base addresses
unsigned long boardtype[MAX_FCASYNC_BOARDS];
struct pci_dev *pcidev[MAX_FCASYNC_BOARDS];
unsigned irq[MAX_FCASYNC_BOARDS];//holds all needed IRQ's
struct pci_dev *pdev = NULL;//to get base addresses from pci subsystem
Fcasync_Dev *dev;//needed everywhere


for(i=0;i<MAX_FCASYNC_BOARDS;i++)
{
//start blank
uartbase[i] = 0;
irq[i] = 0;
pcidev[i] = NULL;
}
index = 0;
#ifdef CONFIG_PCI
#ifdef USE_2_6
if(1)
#else
if(pci_present())
#endif
	{
	while((pdev=pci_get_device(PCI_VENDOR_ID_COMMTECH_FASTCOM,PCI_DEVICE_ID_FC4222335,pdev)))
		{
		//ok here we have a board at bus/function, so get its stats
		pci_enable_device(pdev);
		irq[index]  = pdev->irq;
		uartbase[index] = pci_resource_start (pdev, 0) & PCI_BASE_ADDRESS_MEM_MASK;
		boardtype[index] = FC4222;
		pcidev[index] = pdev;
		printk(KERN_DEBUG "\nFastcom:422/2-PCI-335 BASE: uart: %lx irq: %d\n",uartbase[index],irq[index]);
		index++;
		if(index==MAX_FCASYNC_BOARDS)
			{
			printk("max Fastcom: async boards located\n");
			printk("rebuild with larger MAX_FCASYNC_BOARDS\n");
			goto done;
			}
		}
	while((pdev=pci_get_device(PCI_VENDOR_ID_COMMTECH_FASTCOM,PCI_DEVICE_ID_FC4224335,pdev)))
		{
		//ok here we have a board at bus/function, so get its stats
		pci_enable_device(pdev);
		irq[index]  = pdev->irq;
		uartbase[index] = pci_resource_start (pdev, 0) & PCI_BASE_ADDRESS_MEM_MASK;
		boardtype[index] = FC4224;
		pcidev[index] = pdev;
		printk(KERN_DEBUG "\nFastcom:422/4-PCI-335 BASE: uart: %lx irq: %d\n",uartbase[index],irq[index]);
		index++;
		if(index==MAX_FCASYNC_BOARDS)
			{
			printk("max Fastcom: async boards located\n");
			printk("rebuild with larger MAX_FCASYNC_BOARDS\n");
			goto done;
			}

		}
	while((pdev=pci_get_device(PCI_VENDOR_ID_COMMTECH_FASTCOM,PCI_DEVICE_ID_FC2324335,pdev)))
		{
		//ok here we have a board at bus/function, so get its stats
		pci_enable_device(pdev);
		irq[index]  = pdev->irq;
		uartbase[index] = pci_resource_start (pdev, 0) & PCI_BASE_ADDRESS_MEM_MASK;
		boardtype[index] = FC2324;
		pcidev[index] = pdev;
		printk(KERN_DEBUG "\nFastcom:232/4-PCI-335 BASE: uart: %lx irq: %d\n",uartbase[index],irq[index]);
		index++;
		if(index==MAX_FCASYNC_BOARDS)
			{
			printk("max Fastcom: async boards located\n");
			printk("rebuild with larger MAX_FCASYNC_BOARDS\n");
			goto done;
			}

		}
      while ((pdev =
	      pci_get_device (PCI_VENDOR_ID_COMMTECH_FASTCOM,
			      PCI_DEVICE_ID_FC2328335, pdev)))
	{
	  //ok here we have a board at bus/function, so get its stats
	  pci_enable_device (pdev);
	  irq[index] = pdev->irq;
	  uartbase[index] =
	    pci_resource_start (pdev, 0) & PCI_BASE_ADDRESS_MEM_MASK;
	  boardtype[index] = FC2328;
	  pcidev[index] = pdev;
	  printk (KERN_DEBUG
		  "\nFastcom:232/8-PCI-335 BASE: uart: %lx irq: %d\n",
		  uartbase[index], irq[index]);
	  index++;
	  if (index == MAX_FCASYNC_BOARDS)
	    {
	      printk ("max Fastcom: async boards located\n");
	      printk ("rebuild with larger MAX_FCASYNC_BOARDS\n");
	      goto done;
	    }

	}    
    }
  else
    return -ENODEV;
done:
if(index == 0) return -ENODEV;
#else
return -ENODEV;
#endif
//if we get here then we have index # of fastcom async pci boards, and their particulars are
//stored in amccbase[] uartbase[] configbase[] boardtype[] and irq[]    
   /*
     * Register your major, and accept a dynamic number
     */
fcasync_nr_devs = index;
    result = register_chrdev(fcasync_major, "fcasync335", &fcasync_fops);
    if (result < 0) {
        printk(KERN_WARNING "fcasync: can't get major %d\n",fcasync_major);
        return result;
    }
    if (fcasync_major == 0) fcasync_major = result; /* dynamic */

    /* 
     * allocate the devices  
     */
    fcasync_devices = kmalloc(fcasync_nr_devs * sizeof (Fcasync_Dev), GFP_KERNEL);
    if (!fcasync_devices) {
        result = -ENOMEM;
        goto fail_malloc;
    }
    memset(fcasync_devices, 0, fcasync_nr_devs * sizeof (Fcasync_Dev));
    for (i=0; i < fcasync_nr_devs; i++) {
	//set per instance data here
    }
    /* At this point call the init function for any friend device */
    /* ... */
#ifdef USE_2_6
#else
EXPORT_NO_SYMBOLS;
#endif

//here we setup each board/channel 
for(i=0;i<index;i++) //do for all boards that we found in PCI space
{
//add channel 0
dev = &fcasync_devices[i];
dev->uartbase = uartbase[i];
dev->irq = irq[i];
dev->boardtype = boardtype[i];
dev->pdev = pcidev[i];
}

#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0)
  proc_fcasync_entry = create_proc_entry ("fcasync", S_IFREG | S_IRUGO, 0);
  if (!proc_fcasync_entry)
    printk ("fcasync Cannot create proc entry!\n");
  else
    {

      proc_fcasync_entry->size = 20;
      proc_fcasync_entry->namelen = 10;
      proc_fcasync_entry->nlink = 1;
      proc_fcasync_entry->name = "fcasync335";
      proc_fcasync_entry->mode = S_IFREG | S_IRUGO;
      proc_fcasync_entry->proc_fops = &fcasync_fops;
      proc_fcasync_entry->read_proc = &fcasync_read_procmem;
    }
#else
  proc_register (&proc_root, &fcasync_proc_entry);
#endif

    return 0; /* succeed */

  fail_malloc: unregister_chrdev(fcasync_major, "fcasync335");
    return result;
}

//called on module unload
//clean up everything allocated here
#ifdef USE_2_6
static void __exit fcasync_cleanup(void)
#else
void cleanup_module(void)
#endif
{
Fcasync_Dev *dev;
int i;    

    unregister_chrdev(fcasync_major, "fcasync335");

#if LINUX_VERSION_CODE >= VERSION_CODE(2,4,0) 
	remove_proc_entry("fcasync_335",0);
#else
	proc_unregister(&proc_root, fcasync_proc_entry.low_ino);
#endif

for(i=0;i<fcasync_nr_devs;i++)
{
dev = &fcasync_devices[i];
}
//any cleanup then
kfree(fcasync_devices);
/* and call the cleanup functions for friend devices */

}

#ifdef USE_2_6
module_exit(fcasync_cleanup);
module_init(fcasync_init);
#endif


