/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * setauto485.c -- user utility to configure a Fastcom async pci 335 board
 *
 ******************************************************/

/* $Id$ */

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

techsupport@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int
main (int argc, char *argv[])
{
  int fd;
  unsigned long datain;
  if (argc < 3)
    {
      printf ("usage:%s /dev/fcasyncX auto485\n", argv[0]);
      printf ("\tauto485 is accepted as a hex byte and is:\n");
      printf ("\t0=auto485 disable - 1=auto485 enable\n");
      printf ("\n");
      printf ("\tbit0 =>auto485 channel 0\n");
      printf ("\tbit1 =>auto485 channel 1\n");
      printf ("\tbit2 =>auto485 channel 2\n");
      printf ("\tbit3 =>auto485 channel 3\n");
      printf ("\tbit4 =>auto485 channel 4\n");
      printf ("\tbit5 =>auto485 channel 5\n");
      printf ("\tbit6 =>auto485 channel 6\n");
      printf ("\tbit7 =>auto485 channel 7\n");
      printf ("\n");
      exit (1);
    }
  sscanf (argv[2], "%lx", &datain);
  datain = datain & 0xFF;
  fd = open (argv[1], O_RDWR);
  if (fd != -1)
    {
      if (ioctl (fd, FCASYNC_SET_AUTO485, &datain) == 0)
	{
	  printf ("%s set to %lx\n", argv[1], datain);
	  printf ("auto485 ch0 is ");
	  if ((datain & 0x001) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch1 is ");
	  if ((datain & 0x002) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch2 is ");
	  if ((datain & 0x004) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch3 is ");
	  if ((datain & 0x008) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch4 is ");
	  if ((datain & 0x010) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch5 is ");
	  if ((datain & 0x020) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch6 is ");
	  if ((datain & 0x040) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");
	  printf ("auto485 ch7 is ");
	  if ((datain & 0x080) == 0)
	    printf ("disabled\n");
	  else
	    printf ("enabled\n");

	}
      else
	printf ("error setting auto485!\n");
    }
  else
    {
      printf ("cannot open %s\n", argv[1]);
      exit (1);
    }
}
