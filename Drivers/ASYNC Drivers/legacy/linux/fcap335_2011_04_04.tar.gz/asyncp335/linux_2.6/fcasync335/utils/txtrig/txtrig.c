/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * txtrig.c -- user utility to configure a Fastcom async pci 335 board
 *
 ******************************************************/

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

techsupport@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int
main (int argc, char *argv[])
{
  int fd;
  unsigned char datain[2];
  if (argc < 3)
    {
      printf ("usage:%s /dev/fcasyncX port level\n", argv[0]);
      printf ("\tport is accepted as a hex byte and should be the port you wish to operate on (0-7)\n");
      printf ("\tlevel is accepted as a hex byte and should be from 1 to 63\n");
      printf ("\n");
      exit (1);
    }
  sscanf (argv[2], "%x", &datain[0]);
  sscanf (argv[3], "%x", &datain[1]);
  fd = open (argv[1], O_RDWR);
  if (fd != -1)
    {
      if (ioctl (fd, FCASYNC_SET_TX_TRIG, &datain) == 0)
	  printf ("Port %x set to the level %x on %s\n", datain[0], datain[1], argv[1]);
      else
	printf ("Error setting TX trigger!\n");
    }
  else
    {
      printf ("Cannot open %s\n", argv[1]);
      exit (1);
    }
}
