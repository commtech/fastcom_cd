#!/bin/bash
MAXPORTS=8
TTYNAME=fcasync
DEVNAME=fcasync335
port=0
portname=0
tty_major=`cat /proc/devices | awk "\\$2==\"${DEVNAME}\" {print \\$1}"`
echo
echo "Fastcom Asynchronous PCI-335 Family Multiport Board Make Node Utility."
echo "Making $MAXPORTS dev nodes for Fastcom ports by default: /dev/${TTYNAME}${port} - /dev/${TTYNAME}1F"
echo
while [ $port -lt $MAXPORTS ]
do
        [ -c /dev/$TTYNAME$portname ] && rm -f /dev/$TTYNAME$portname
                                                                                
        mknod /dev/$TTYNAME$portname c $tty_major $port
                                                                                
        chmod a+wx /dev/$TTYNAME$portname
                                                                                
        port=`expr $port + 1`
	portname=$port
	portname=$(echo "$portname 16 o p" | dc)
done

# $Id$
