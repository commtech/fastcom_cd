/******************************************************
 *
 * Copyright (C) 2006 Commtech, Inc. Wichita KS
 *
 * rxecho.c -- user utility to configure a Fastcom async pci 335 board
 *
 ******************************************************/

/* $Id$ */

/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

If you encounter problems or have suggestions and/or bug fixes please email them to:

techsupport@commtech-fastcom.com

or mailed to:

Commtech, Inc.
9011 E. 37th N.
Wichita, KS 67226
ATTN: Linux BugFix Dept

*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "../fcasync.h"

int
main (int argc, char *argv[])
{
  int fd;
  unsigned long datain;
  if (argc < 3)
    {
      printf ("usage:%s /dev/fcasyncX datain\n", argv[0]);
      printf ("\tdatain = 0 RxEchoCancel is disabled\n");
      printf ("\tdatain = 1 RxEchoCancel is enabled\n");
      printf ("\n");
      exit (1);
    }
  sscanf (argv[2], "%lx", &datain);
  fd = open (argv[1], O_RDWR);
  if (fd != -1)
    {
      if (ioctl (fd, FCASYNC_SET_RXECHO, &datain) == 0)
	{
	  printf ("%s set to %lx\n", argv[1], datain);
	  printf ("Receive Echo Cancel (global) is ");
	  if (datain)
	    printf ("ON\n");
          else
            printf ("OFF\n");
	}
      else
	printf ("error setting rxecho!\n");
    }
  else
    {
      printf ("cannot open %s\n", argv[1]);
      exit (1);
    }
}
